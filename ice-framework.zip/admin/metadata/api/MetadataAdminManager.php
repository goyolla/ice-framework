<?php
if (!class_exists('MetadataAdminManager')) {
	
	class MetadataAdminManager extends AbstractModuleManager{
		
		public function initializeUserClasses(){
			
		}
		
		public function initializeFieldMappings(){
			
		}
		
		public function initializeDatabaseErrorMappings(){
			
		}
		
		public function setupModuleClassDefinitions(){			
			
		}
		
	}
}