<?php
if (!class_exists('SettingsAdminManager')) {
	class SettingsAdminManager extends AbstractModuleManager{
		
		public function initializeUserClasses(){
			
		}
		
		public function initializeFieldMappings(){
			
		}
		
		public function initializeDatabaseErrorMappings(){

		}
		
		public function setupModuleClassDefinitions(){
			
			//This is a fixed module, store model classes in models.inc.php
		}
		
	}
}