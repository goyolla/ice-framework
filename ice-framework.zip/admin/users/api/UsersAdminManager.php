<?php
if (!class_exists('UsersAdminManager')) {
	class UsersAdminManager extends AbstractModuleManager{

		public function initializeUserClasses(){
				
		}

		public function initializeFieldMappings(){
				
		}

		public function initializeDatabaseErrorMappings(){

		}

		public function setupModuleClassDefinitions(){
				
			//This is a fixed module, store model classes in models.inc.php
		}

	}
}