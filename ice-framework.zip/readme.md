IceHrm
===========

Installation
------------
Download the latest release https://sourceforge.net/projects/icehrm/

Copy the downloaded file to the path you want to install iCE Hrm in your server and extract.

Create a mysql DB for and user. Grant all on iCE Hrm DB to new DB user.

Visit iCE Hrm installation path in your browser.

During the installation form, fill in details appropriately.

Once the application is installed use the username = admin and password = admin to login to your system.

Note: Please rename or delete the install folder (<ice hrm root>/app/install) since it could pose a security threat to your iCE Hrm instance.


Updating v5.x to v6.0
---------------------
Run the script icehrmdb_update_v5.3_to_v6.0.sql on your icehrm db after taking a backup

Delete all files and folders in <icehrm> folder except <icehrm>/app folder

Copy all contects in icehrm_v6.0.zip except app folder

Login as admin and set setting "System: Reset Modules and Permissions" to Yes

Release note v6.0
-----------------
* Features
* Notifications for leaves and timesheets
* Leave module accrue and leave carry forward
* Profile leave entitlement sub module
* Ability to put system on debug mode
* Allow admins to see documents of all the profiles at one place
* Backup data when deleting an profile
* Profile attendance report added
* Changes to time entry form in timesheet module to make time entry process faster
* Admin can make all projects available to profiles or just the set of prjects assigned to them using Setting "Projects: Make All Projects Available to Profiles"
* Profile document, date added field can not be changed by the profile anymore
* About dialog added for admins

* Fixes
* Fix default profile delete issue (when the default profile is deleted the admin user attached to it also get deleted)
* Fix user duplicate email issue
* Fix manager can not logout from switched profile
* Remove admin guide from non admin users

Release note v5.3
-----------------
* Fixes
* Fix missing profile name in profile details report

Release note v5.2
-----------------
* Fixes
* Remove unwanted error logs
* Fix attendance module profile permission issue
* Resolve warnings
* Remove add new button from subordinates module
* Adding administrators' guide

Release note v5.1
-----------------
* Fixes
* Fixing for non updating null fields
* https://bitbucket.org/thilina/icehrm-opensource/commits/df57308b53484a2e43ef5c72967ed1cd0dc756cc

Release note v5.0
-----------------
* Features
* New user permission implementation
* Adding new user level - Manager

* Fixes
* Fixing remote table loading issue

Release note v4.2
-----------------
* Fixes
* https://bitbucket.org/thilina/icehrm-opensource/issue/23/subordinate-leaves-pagination-not-working
* https://bitbucket.org/thilina/icehrm-opensource/issue/20/error-occured-while-time-punch


Release note v4.1
-----------------
* Features
* Better email format for notifications
* Convert upload dialog to a bootstrp model

* Fixes
* Fix error sending emails with amazon SES
* Fix errors related to XAMPP and WAMPP servers
* Fix php warnings and notifications
* Fix company structure graph issues
* Allow icehrm client to work without an internet connection
* Fix installer incorrect base url issue
* Fix empty user creation issue